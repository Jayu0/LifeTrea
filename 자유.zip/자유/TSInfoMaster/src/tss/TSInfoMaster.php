<?php

namespace tss;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\item\Item;
use pocketmine\item\Block;
use pocketmine\entity\effect;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\scheduler\PluginTask;
use pocketmine\event\player\PlayerChatEvent;

class TSInfoMaster extends PluginBase implements Listener {
	private $timer, $EconomyS;
	public function onEnable() {
		@mkdir ( $this->getDataFolder () );
		$config = new Config ( $this->getDataFolder () . "/info.yml", Config::YAML );
		$this->getServer ()->getPluginManager ()->registerEvents ( $this, $this );
		$this->EconomyS = $this->getServer ()->getPluginManager ()->getPlugin ( "EconomyAPI" );
		$this->getServer ()->getScheduler ()->scheduleRepeatingTask ( new TSInfoMasterTask ( $this ), 30 );
		$this->timer = 0;
	}
	public function onCommand(CommandSender $player, Command $cmd, $label, array $args) {
		switch ($cmd->getName ()) {
			
			case "정보" :
				if (! isset ( $args [0] )) {
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =" );
    				$player->sendMessage ( "§f TSInfoMaster 은 종이를 들때 유저가 원하는 맛대로 설정한 정보를 보여줍니다.\n" );
					$player->sendMessage ( "§7 종이는 스폰에서 얻으실 수 있습니다.\n" );
					$player->sendMessage ( "§b /정보 유저정보 §f- 종이를 들때 유저의 정보를 보여줍니다." );
					$player->sendMessage ( "§b /정보 서버정보 §f- 종이를 들때 서버의 정보를 보여줍니다." );
					$player->sendMessage ( "§b /정보 스폰이동 §f- 종이를 들때 자신의 돈을 보여줍니다." );
					$player->sendMessage ( "§b /정보 시각 §f- 종이를 들때 대한민국의 날짜와 현재 시각을 보여줍니다." );
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =" );
					return true;
				}
				if ($args [0] == "유저정보") {
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =" );
					$player->sendMessage ( "§f 종이에 정보를 성공적으로 저장하였습니다.\n§f 앞으로 종이에서는 §b당신의 정보§f가 보입니다." );
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =\n " );
					$config = new Config ( $this->getDataFolder () . "/info.yml", Config::YAML );
					$config->set ( $player->getName (), "showuser" );
					$config->save ();
					return true;
				}
				if ($args [0] == "서버정보") {
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =" );
					$player->sendMessage ( "§f 종이에 정보를 성공적으로 저장하였습니다.\n§f 앞으로 종이에서는 §b서버의 정보§f가 보입니다." );
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =\n " );
					$config = new Config ( $this->getDataFolder () . "/info.yml", Config::YAML );
					$config->set ( $player->getName (), "showserver" );
					$config->save ();
					return true;
				}
				if ($args [0] == "스폰이동") {
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =" );
					$player->sendMessage ( "§f 종이에 정보를 성공적으로 저장하였습니다.\n§f 앞으로 종이를 들면 §b서버의 스폰§f으로 이동합니다." );
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =\n " );
					$config = new Config ( $this->getDataFolder () . "/info.yml", Config::YAML );
					$config->set ( $player->getName (), "showserver" );
					$config->save ();
					return true;
				}
				if ($args [0] == "시각") {
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =" );
					$player->sendMessage ( "§f 종이에 정보를 성공적으로 저장하였습니다.\n§f 앞으로 종이를 들시 §b현재 날짜와 시간§f을 보여줍니다." );
					$player->sendMessage ( "§a= = = = = = = = = = = = = = = = = = = = = = = =\n " );
					$config = new Config ( $this->getDataFolder () . "/info.yml", Config::YAML );
					$config->set ( $player->getName (), "showtime" );
					$config->save ();
					return true;
				}
		}
	}
}
class TSInfoMasterTask extends PluginTask {
	private $timer, $EconomyS;
	public function onRun($currentTick) {
		foreach ( $this->getOwner ()->getServer ()->getOnlinePlayers () as $players ) {
			$Name = $players->getPlayer ()->getName ();
			$economyAPI = \onebone\economyapi\EconomyAPI::getInstance ();
			$Money = $economyAPI->myMoney ( $Name );
			$Online = count ( Server::getInstance ()->getOnlinePlayers () );
			$Full = $this->getOwner ()->getServer ()->getMaxPlayers ();
			$config = new Config ( $this->getOwner ()->getDataFolder () . "/info.yml", Config::YAML );
			$Health = $players->getPlayer ()->getHealth ();
			$MaxHealth = $players->getPlayer ()->getMaxHealth ();
			$item = $players->getInventory ()->getItemInHand ();
			if ($item->getId () === Item::PAPER) {
				
				$info = "-1";
				
				if ($config->get ( $players->getPlayer ()->getName () ) != null) {
					$info = $config->get ( $players->getPlayer ()->getName () );
				}
				
				if ($info == "showuser") {
					$players->sendTip ( "§b[ §a정보를 유저가 입맛대로 설정한다! §fTSInfoMaster §b]\n \n§b        당신의 닉네임:§f $Name   §b돈:§f $Money   §b체력:§f $Health/$MaxHealth" );
				}
				if ($info == "showserver") {
					$players->sendTip ( "§b[ §a정보를 유저가 입맛대로 설정한다! §fTSInfoMaster §b]\n \n§6 서버이름: §f티에스온라인   §6접속인원:§f $Online/$Full" );
				}
				if ($info == "gospawn") {
					$players->sendTip ( "§b[ §a정보를 유저가 입맛대로 설정한다! §fTSInfoMaster §b]\n \n§f      이 기능은 현재 준비 중 입니다.." );
				}
				if ($info == "showtime") {
					$players->sendTip ( "§b[ §a정보를 유저가 입맛대로 설정한다! §fTSInfoMaster §b]\n \n§f        이 기능은 현재 준비 중 입니다." );
				}
				if (!$info == "gospawn" || !$info == "showserver" || !$info == "showuser" || !$info == "showtime") {
					$players->sendTip ( "§b " . $Name . "님 §f현재 종이에 정보를 등록하지 않으셨습니다.\n §6/정보 §f명령어를 통해 종이에 정보등록을 해주시길 바랍니다." );
				}
			}
		}
	}
}

