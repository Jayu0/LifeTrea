<?php

namespace tss;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;
use onebone\economyapi\EconomyAPI;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\utils\Config;
use pocketmine\item\Item;
use pocketmine\item\Emerald;
use pocketmine\scheduler\PluginTask;
use pocketmine\block\Block;
use pocketmine\level\sound\ExplodeSound;
use pocketmine\level\sound\ClickSound;
use pocketmine\utils\TextFormat;
use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerItemHeldEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;

class TSMysteryBox extends PluginBase implements Listener {
	public function onEnable() {
		@mkdir ( $this->getDataFolder () );
		$this->getServer ()->getPluginManager ()->registerEvents ( $this, $this );
		$this->economy = $this->getServer ()->getPluginManager ()->getPlugin ( "EconomyAPI" );
		$this->getServer ()->getScheduler ()->scheduleRepeatingTask ( new TSMysteryBoxTask ( $this ), 20 );
		$this->timer = 0;
	}
	public function onInteract(PlayerInteractEvent $event) {
		$block = $event->getBlock ();
		$player = $event->getPlayer ();
		$inventory = $player->getInventory ();
		$level = $player->getLevel ();
		$item = $player->getInventory ()->getItemInHand ();
		
		if ($block->getId () === Block::END_PORTAL_FRAME) {
			if (! $item->getId () === Item::GHAST_TEAR || ! $item->getId () === Item::SLIMEBALL || ! $item->getId () === Item::MAGMA_CREAM) { // 박스를 클릭했을 때 손에 열쇠가 없을 경우
				$player->sendMessage ( "§b[ §a미스테리 박스 §b] §f하급, 중급, 상급 중 한가지를 손에 든 후 클릭해주세요!" );
			}
		}
		
		// 하급박스 -------------------------------------------------------------------------------------------------------------
		if ($block->getId () === Block::END_PORTAL_FRAME) {
			if ($item->getId () === Item::GHAST_TEAR) { // 클릭했을 때 가스트의 눈물로 클릭했을 시
				$player->getInventory ()->removeItem ( new Item ( 370, 0, 1 ) );
				
				$prize = rand ( 1, 16 );
				
				switch ($prize) {
					case 1 :
						$inventory->addItem ( Item::get ( 267, 0, 1 ) ); // 철 칼
						$inventory->addItem ( Item::get ( 256, 0, 1 ) ); // 철 삽
						$inventory->addItem ( Item::get ( 257, 0, 1 ) ); // 철 곡괭이
						$inventory->addItem ( Item::get ( 258, 0, 1 ) ); // 철 도끼
						$inventory->addItem ( Item::get ( 292, 0, 1 ) ); // 철 괭이
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: 철도구 세트  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						break;
					case 2 :
						$inventory->addItem ( Item::get ( 302, 0, 1 ) ); // 사슬 헬멧
						$inventory->addItem ( Item::get ( 303, 0, 1 ) ); // 사슬 갑옷
						$inventory->addItem ( Item::get ( 304, 0, 1 ) ); // 사슬 바지
						$inventory->addItem ( Item::get ( 305, 0, 1 ) ); // 사슬 신발
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §7사슬갑옷 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 3 :
						$inventory->addItem ( Item::get ( 272, 0, 1 ) ); // 돌 칼
						$inventory->addItem ( Item::get ( 273, 0, 1 ) ); // 돌 삽
						$inventory->addItem ( Item::get ( 274, 0, 1 ) ); // 돌 곡괭이
						$inventory->addItem ( Item::get ( 275, 0, 1 ) ); // 돌 도끼
						$inventory->addItem ( Item::get ( 291, 0, 1 ) ); // 돌 괭이
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §7돌도구 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 4 :
						$inventory->addItem ( Item::get ( 272, 0, 1 ) ); // 돌 칼
						$inventory->addItem ( Item::get ( 273, 0, 1 ) ); // 돌 삽
						$inventory->addItem ( Item::get ( 274, 0, 1 ) ); // 돌 곡괭이
						$inventory->addItem ( Item::get ( 275, 0, 1 ) ); // 돌 도끼
						$inventory->addItem ( Item::get ( 291, 0, 1 ) ); // 돌 괭이
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §7돌도구 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 5 :
						$inventory->addItem ( Item::get ( 267, 0, 1 ) ); // 철 칼
						$inventory->addItem ( Item::get ( 256, 0, 1 ) ); // 철 삽
						$inventory->addItem ( Item::get ( 257, 0, 1 ) ); // 철 곡괭이
						$inventory->addItem ( Item::get ( 258, 0, 1 ) ); // 철 도끼
						$inventory->addItem ( Item::get ( 292, 0, 1 ) ); // 철 괭이
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: 철도구 세트  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 6 :
						$inventory->addItem ( Item::get ( 370, 0, 8 ) ); // 가스트의 눈물
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §6하급열쇠 8개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 7 :
						$this->economy->addMoney ( $player, 5000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 5000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 8 :
						$this->economy->addMoney ( $player, 10000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 10000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 9 :
						$this->economy->addMoney ( $player, 20000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 20000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 10 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         하급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8풉..ㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 11 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         하급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8티에스: 개이득\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 12 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         하급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 13 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         하급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 14 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         하급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8열쇠는 내가 가져가도록 하지\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 15 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         하급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8다시 시도하세요!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 16 :
						$inventory->addItem ( Item::get ( 373, 15, 3 ) ); // 신속포션
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b신속포션 3개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 16 :
						$inventory->addItem ( Item::get ( 3, 0, 1 ) );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§6         하급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §7돌도구 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
				}
			}
		}
		// 중급박스 -------------------------------------------------------------------------------------------------------------
		if ($block->getId () === Block::END_PORTAL_FRAME) {
			if ($item->getId () === Item::SLIMEBALL) { // 클릭했을 때 슬라임볼로 클릭했을 시
				$player->getInventory ()->removeItem ( new Item ( 341, 0, 1 ) );
				
				$prize = rand ( 1, 40 );
				
				switch ($prize) {
					case 1 :
						$inventory->addItem ( Item::get ( 306, 0, 1 ) ); // 철 헬멧
						$inventory->addItem ( Item::get ( 307, 0, 1 ) ); // 철 갑옷
						$inventory->addItem ( Item::get ( 308, 0, 1 ) ); // 철 바지
						$inventory->addItem ( Item::get ( 309, 0, 1 ) ); // 철 신발
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: 철갑옷 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 2 :
						$inventory->addItem ( Item::get ( 314, 0, 1 ) ); // 금 헬멧
						$inventory->addItem ( Item::get ( 315, 0, 1 ) ); // 금 갑옷
						$inventory->addItem ( Item::get ( 316, 0, 1 ) ); // 금 바지
						$inventory->addItem ( Item::get ( 317, 0, 1 ) ); // 금 신발
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §7사슬갑옷 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 3 :
						$inventory->addItem ( Item::get ( 310, 0, 1 ) ); // 다이아 헬멧
						$inventory->addItem ( Item::get ( 312, 0, 1 ) ); // 다이아 바지
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b다이아몬드 갑옷 (세트 X)   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 4 :
						$inventory->addItem ( Item::get ( 311, 0, 1 ) ); // 다이아 갑옷
						$inventory->addItem ( Item::get ( 313, 0, 1 ) ); // 다이아 신발
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b다이아몬드 갑옷 (세트 X)   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 5 :
						$inventory->addItem ( Item::get ( 276, 0, 1 ) ); // 다이아몬드 검
						$inventory->addItem ( Item::get ( 293, 0, 1 ) ); // 다이아몬드 괭이
						$inventory->addItem ( Item::get ( 278, 0, 1 ) ); // 다이아몬드 곡괭이
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b다이아몬드 도구 (세트 X)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 6 :
						$inventory->addItem ( Item::get ( 279, 0, 1 ) ); // 다이아몬드 도끼
						$inventory->addItem ( Item::get ( 278, 0, 1 ) ); // 다이아몬드 곡괭이
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b다이아몬드 도구 (세트 X)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 7 :
						$inventory->addItem ( Item::get ( 373, 21, 2 ) ); // 즉시회복 1단계
						$inventory->addItem ( Item::get ( 373, 15, 2 ) ); // 신속 1단계
						$inventory->addItem ( Item::get ( 373, 28, 2 ) ); // 재생 1단계
						$inventory->addItem ( Item::get ( 373, 32, 2 ) ); // 힘 1단계
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §d버프포션 1단계 세트(2개)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 8 :
						$inventory->addItem ( Item::get ( 262, 27, 4 ) ); // 독 화살
						$inventory->addItem ( Item::get ( 262, 19, 4 ) ); // 구속 화살
						$inventory->addItem ( Item::get ( 262, 24, 4 ) ); // 즉시피해 화살
						$inventory->addItem ( Item::get ( 262, 36, 4 ) ); // 나약함 화살
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §a디버프 화살 세트 (4개)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 9 :
						$inventory->addItem ( Item::get ( 262, 27, 8 ) ); // 독 화살
						$inventory->addItem ( Item::get ( 262, 19, 8 ) ); // 구속 화살
						$inventory->addItem ( Item::get ( 262, 24, 8 ) ); // 즉시피해 화살
						$inventory->addItem ( Item::get ( 262, 36, 8 ) ); // 나약함 화살
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §a디버프 화살 세트 (8개)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 10 :
						$inventory->addItem ( Item::get ( 341, 0, 3 ) ); // 중급열쇠
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §9중급열쇠 3개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 11 :
						$inventory->addItem ( Item::get ( 341, 0, 5 ) ); // 중급열쇠
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §9중급열쇠 5개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 12 :
						$inventory->addItem ( Item::get ( 378, 0, 3 ) ); // 상급열쇠
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b상급열쇠 3개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 13 :
						$inventory->addItem ( Item::get ( 378, 0, 4 ) ); // 상급열쇠
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b상급열쇠 4개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 14 :
						$this->economy->addMoney ( $player, 25000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 25000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 15 :
						$this->economy->addMoney ( $player, 30000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 30000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 16 :
						$this->economy->addMoney ( $player, 40000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 40000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 17 :
						$this->economy->addMoney ( $player, 50000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 50000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 18 :
						$this->economy->addMoney ( $player, 60000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§9         중급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 60000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 19 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8어머! 얘 터졌나봐!!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 20 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8친구: 너 설마 터졌니?\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 21 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8펑!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 22 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8다음 기회에!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 23 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8티에스: ㅋ?\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 24 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8파뤼 타임!!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 25 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
case 26:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
		    case 27 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
case 28 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
case 29:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;

case 30 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;

case 31:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 32:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 33 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 34 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 35:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 36 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 37 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 38 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 39:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				
case 40 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         중급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
			}
		}
}
		// 상급박스 -------------------------------------------------------------------------------------------------------------
		if ($block->getId () === Block::END_PORTAL_FRAME) {
			if ($item->getId () === Item::MAGMA_CREAM) { // 클릭했을 때 슬라임볼로 클릭했을 시
				$player->getInventory ()->removeItem ( new Item ( 378, 0, 1 ) );
				
				$prize = rand ( 1, 40);
				
				switch ($prize) {
					case 1 :
						$inventory->addItem ( Item::get ( 306, 0, 1 ) ); // 철 헬멧
						$inventory->addItem ( Item::get ( 307, 0, 1 ) ); // 철 갑옷
						$inventory->addItem ( Item::get ( 308, 0, 1 ) ); // 철 바지
						$inventory->addItem ( Item::get ( 309, 0, 1 ) ); // 철 신발
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: 철갑옷 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 2 :
						$inventory->addItem ( Item::get ( 310, 0, 1 ) ); // 다이아 헬멧
						$inventory->addItem ( Item::get ( 311, 0, 1 ) ); // 다이아 갑옷
						$inventory->addItem ( Item::get ( 312, 0, 1 ) ); // 다이아 바지
						$inventory->addItem ( Item::get ( 313, 0, 1 ) ); // 다이아 신발
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b다이아갑옷 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 3 :
						$inventory->addItem ( Item::get ( 276, 0, 1 ) ); // 다이아 칼
						$inventory->addItem ( Item::get ( 278, 0, 1 ) ); // 다이아 곡괭이
						$inventory->addItem ( Item::get ( 279, 0, 1 ) ); // 다이아 도끼
						$inventory->addItem ( Item::get ( 293, 0, 1 ) ); // 다이아 괭이
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b다이아도구 세트   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 4 :
						$inventory->addItem ( Item::get ( 373, 21, 3 ) ); // 즉시회복 1단계
						$inventory->addItem ( Item::get ( 373, 15, 3 ) ); // 신속 1단계
						$inventory->addItem ( Item::get ( 373, 28, 3 ) ); // 재생 1단계
						$inventory->addItem ( Item::get ( 373, 32, 3 ) ); // 힘 1단계
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §d버프포션 2단계 세트 (3개)   §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 5 :
						$inventory->addItem ( Item::get ( 373, 22, 3 ) ); // 즉시회복 2단계
						$inventory->addItem ( Item::get ( 373, 16, 3 ) ); // 신속 2단계
						$inventory->addItem ( Item::get ( 373, 30, 3 ) ); // 재생 2단계
						$inventory->addItem ( Item::get ( 373, 33, 3 ) ); // 힘 2단계
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §d버프포션 2단계 세트 (3개)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 6 :
						$inventory->addItem ( Item::get ( 438, 21, 3 ) ); // 투척용 즉시회복1
						$inventory->addItem ( Item::get ( 438, 15, 3 ) ); // 투척용 신속1
						$inventory->addItem ( Item::get ( 438, 29, 3 ) ); // 투척용 재생1
						$inventory->addItem ( Item::get ( 438, 32, 3 ) ); // 투척용 힘1 
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §6투척용 버프포션 1단계 세트 (3개)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 7 :
						$inventory->addItem ( Item::get ( 438, 22, 3 ) ); // 투척용 즉시회복2
						$inventory->addItem ( Item::get ( 438, 16, 3 ) ); // 투척용 신속2
						$inventory->addItem ( Item::get ( 438, 30, 3 ) ); // 투척용 재생2
						$inventory->addItem ( Item::get ( 438, 33, 3 ) ); // 투척용 힘2
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §d버프포션 1단계 2단계 세트(3개)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 8 :
						$inventory->addItem ( Item::get ( 262, 27, 16 ) ); // 독 화살
						$inventory->addItem ( Item::get ( 262, 19, 16 ) ); // 구속 화살
						$inventory->addItem ( Item::get ( 262, 24, 16 ) ); // 즉시피해 화살
						$inventory->addItem ( Item::get ( 262, 36, 16 ) ); // 나약함 화살
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §a디버프 화살 세트 (16개)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 9 :
						$inventory->addItem ( Item::get ( 262, 27, 32 ) ); // 독 화살
						$inventory->addItem ( Item::get ( 262, 19, 32 ) ); // 구속 화살
						$inventory->addItem ( Item::get ( 262, 24, 32 ) ); // 즉시피해 화살
						$inventory->addItem ( Item::get ( 262, 36, 32 ) ); // 나약함 화살
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §a디버프 화살 세트 (32개)  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 10 :
						$inventory->addItem ( Item::get ( 341, 0, 5 ) ); // 중급열쇠
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f         상품: §9중급열쇠 5개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 11 :
						$inventory->addItem ( Item::get ( 341, 0, 6 ) ); // 중급열쇠
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §9중급열쇠 6개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 12 :
						$inventory->addItem ( Item::get ( 378, 0, 3 ) ); // 상급열쇠
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b상급열쇠 3개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 13 :
						$inventory->addItem ( Item::get ( 378, 0, 2 ) ); // 상급열쇠
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §b상급열쇠 2개  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 14 :
						$this->economy->addMoney ( $player, 40000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 40000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 15 :
						$this->economy->addMoney ( $player, 55000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 55000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 16 :
						$this->economy->addMoney ( $player, 75000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 75000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 17 :
						$this->economy->addMoney ( $player, 90000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 90000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 18 :
						$this->economy->addMoney ( $player, 100000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 100000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 19 :
						$this->economy->addMoney ( $player, 115000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 115000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 20 :
						$this->economy->addMoney ( $player, 120000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 110000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 21 :
						$this->economy->addMoney ( $player, 135000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 125000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 22 :
						$this->economy->addMoney ( $player, 150000 ); // 돈
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §e게임머니 150000원  §8축하드립니다!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
					case 23 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8다음 기회에!\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 24 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 25 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8아쉽네요ㅠ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 26 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅅㄱ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
						case 27 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
						case 28 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8화이팅\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
						case 28 :
						$inventory->addItem(Item::get(295,0,64)); //씨앗
			$inventory->addItem(Item::get(361,0,64)); //호박
			$inventory->addItem(Item::get(362,0,64)); //수박
			$inventory->addItem(Item::get(458,0,64)); //사탕무
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §a씨앗 세트  §8씨앗은 사랑입니다.\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
						case 29 :
						$inventory->addItem(Item::get(155,0,64)); //석영
			$inventory->addItem(Item::get(155,1,64)); //석영 1단계
			$inventory->addItem(Item::get(155,2,64)); //석영 2단계
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§b         상급 박스§f가 안전하게 열렸습니다.\n " );
						$player->sendMessage ( "§f        상품: §f석영 세트  §8씨앗은 사랑입니다.\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ClickSound ( $player ) );
						break;
											case 30 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
											case 31 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 32 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 33 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 34:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 35 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 36 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 37:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 38 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 39:
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
					case 40 :
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$player->sendMessage ( "§c         상급 박스가 터졌습니다!\n " );
						$player->sendMessage ( "§f        상품: §f마음의 상처  §8ㅋㅋㅋㅋㅋ\n " );
						$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = \n " );
						$level->addSound ( new ExplodeSound ( $player ) );
						break;
				}
			}
		}
	}
	public function onCommand(CommandSender $player, Command $cmd, $label, array $args) {
		switch ($cmd->getName ()) {
			
			case "뽑기" :
				if (! isset ( $args [0] )) {
					$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =" );
					$player->sendMessage ( "§f                   무슨 상품이 나올지 궁금하신가요?\n " );
					$player->sendMessage ( "§6 하급: §f/뽑기 하급 §7- 상급박스에 나올 상품들을 확인합니다." );
					$player->sendMessage ( "§9 중급: §f/뽑기 중급 §7- 상급박스에 나올 상품들을 확인합니다." );
					$player->sendMessage ( "§b 상급: §f/뽑기 상급 §7- 상급박스에 나올 상품들을 확인합니다." );
					$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =" );
					return true;
				}
				
				if ($args [0] == "하급") {
					$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =" );
					$player->sendMessage ( "§a                 본 아래 상품들은 하급에서 나오는 상품입니다.\n " );
					$player->sendMessage ( "§b 상품 목록:" );
					$player->sendMessage ( "§b - §6가죽갑옷 세트" );
					$player->sendMessage ( "§b - §7사슬갑옷 세트" );
					$player->sendMessage ( "§b - §7돌도구 세트" );
					$player->sendMessage ( "§b - §f철도구 세트" );
					$player->sendMessage ( "§b - §b신속 포션" );
					$player->sendMessage ( "§b - §6하급열쇠 " );
					$player->sendMessage ( "§6 - §e게임머니 5000 - 20000" );
					$player->sendMessage ( "§6 - §c꽝 (3분의 1)" );
					$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n " );
					return true;
				}
				
				if ($args [0] == "중급") {
					$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =" );
					$player->sendMessage ( "§a                 본 아래 상품들은 중급에서 나오는 상품입니다.\n " );
					$player->sendMessage ( "§b 상품 목록:" );
					$player->sendMessage ( "§b - §f철갑옷 세트" );
					$player->sendMessage ( "§b - §e금갑옷 세트" );
					$player->sendMessage ( "§b - §b다이아몬드 갑옷 (세트 X)" );
					$player->sendMessage ( "§b - §f철도구 세트" );
					$player->sendMessage ( "§b - §b다이아몬드 도구 (세트 X)" );
					$player->sendMessage ( "§b - §d버프포션 세트 (1단계)" );
					$player->sendMessage ( "§b - §a디버프 화살 세트 4-8개" );
					$player->sendMessage ( "§b - §9중급열쇠" );
					$player->sendMessage ( "§b - §b상급열쇠" );
					$player->sendMessage ( "§6 - §e게임머니 25000 - 60000" );
					$player->sendMessage ( "§6 - §c꽝 (3분의 1)" );
					$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n " );
					return true;
				}
				
				if ($args [0] == "상급") {
					$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =" );
					$player->sendMessage ( "§a                 본 아래 상품들은 상급에서 나오는 상품입니다.\n " );
					$player->sendMessage ( "§b 상품 목록:" );
					$player->sendMessage ( "§b - §a씨앗 세트" );
					$player->sendMessage ( "§b - §a석영 세트" );
					$player->sendMessage ( "§b - §f철갑옷 세트" );
					$player->sendMessage ( "§b - §b다이아갑옷 세트" );
					$player->sendMessage ( "§b - §b다이아도구 세트" );
					$player->sendMessage ( "§b - §d버프포션 세트 (1단계-2단계)" );
					$player->sendMessage ( "§b - §6투척용 버프포션 세트 (1단계-2단계)" );
					$player->sendMessage ( "§b - §a디버프 화살 세트 (16-32개)" );
					$player->sendMessage ( "§b - §9중급열쇠" );
					$player->sendMessage ( "§b - §b상급열쇠" );
					$player->sendMessage ( "§6 - §e게임머니 40000 - 150000" );
					$player->sendMessage ( "§6 - §c꽝 (4분의 1)" );
					$player->sendMessage ( "§9= = = = = = = = = = = = = = = = = = = = = = = = = = = = = =\n " );
					return true;
				}
		}
	}
}
class TSMysteryBoxTask extends PluginTask {
	private $timer, $EconomyS;
	public function onRun($currentTick) {
		foreach ( $this->getOwner ()->getServer ()->getOnlinePlayers () as $players ) {
			$Name = $players->getPlayer ()->getName ();
			$economyAPI = \onebone\economyapi\EconomyAPI::getInstance ();
			$Money = $economyAPI->myMoney ( $Name );
			$Online = count ( Server::getInstance ()->getOnlinePlayers () );
			$Full = $this->getOwner ()->getServer ()->getMaxPlayers ();
			$config = new Config ( $this->getOwner ()->getDataFolder () . "/rank.yml", Config::YAML );
			$item = $players->getInventory ()->getItemInHand ();
			
			if ($item->getId () === Item::GHAST_TEAR) {
				$players->sendTip ( "§b                 [ §a미스테리 박스 §b] §7:: §6하급열쇠\n §f무슨 아이템이 나올지 궁금하시다면 §b/뽑기 §f명령어를 입력해주세요." );
			}
			
			if ($item->getId () === Item::SLIMEBALL) {
				$players->sendTip ( "§b                 [ §a미스테리 박스 §b] §7:: §9중급열쇠\n §f무슨 아이템이 나올지 궁금하시다면 §b/뽑기 §f명령어를 입력해주세요." );
			}
			
			if ($item->getId () === Item::MAGMA_CREAM) {
				$players->sendTip ( "§b                 [ §a미스테리 박스 §b] §7:: §b상급열쇠\n §f무슨 아이템이 나올지 궁금하시다면 §b/뽑기 §f명령어를 입력해주세요." );
			}
		}