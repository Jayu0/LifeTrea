<?php

namespace Jayu;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;
use pocketmine\plugin\Plugin;
use pocketmine\Server;
use pocketmine\Player;

class LRHelpMaster extends PluginBase implements Listener {
	public function onEnable() {
		@mkdir ( $this->getDataFolder () );
		$this->getServer ()->getPluginManager ()->registerEvents ( $this, $this );
		$this->getServer ()->getScheduler ()->scheduleRepeatingTask ( new LRHelpMaster.Task ( $this ), 20 );
		$this->timer = 0;
	}
}

class TSMysteryBoxTask extends PluginTask {
	private $timer, $EconomyS;
	public function onRun($currentTick) {
		foreach ( $this->getOwner ()->getServer ()->getOnlinePlayers () as $players ) {
			$Name = $players->getPlayer ()->getName 
			$Online = count ( Server::getInstance ()->getOnlinePlayers () );
			$Full = $this->getOwner ()->getServer ()->getMaxPlayers ();
			$config = new Config ( $this->getOwner ()->getDataFolder () . "/rank.yml", Config::YAML );
			$item = $players->getInventory ()->getItemInHand ();
			
			if ($item->getId () === Item::GHAST_TEAR) {
				$players->sendTip ( "§b                 [ §a미스테리 박스 §b] §7:: §6하급열쇠\n §f무슨 아이템이 나올지 궁금하시다면 §b/뽑기 §f명령어를 입력해주세요." );
			}
			
			if ($item->getId () === Item::SLIMEBALL) {
				$players->sendTip ( "§b                 [ §a미스테리 박스 §b] §7:: §9중급열쇠\n §f무슨 아이템이 나올지 궁금하시다면 §b/뽑기 §f명령어를 입력해주세요." );
			}
			
			if ($item->getId () === Item::MAGMA_CREAM) {
				$players->sendTip ( "§b                 [ §a미스테리 박스 §b] §7:: §b상급열쇠\n §f무슨 아이템이 나올지 궁금하시다면 §b/뽑기 §f명령어를 입력해주세요." );
			}
		}